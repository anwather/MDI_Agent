[DscResource()]
class FileDownload {
    [DscProperty(Key)]
    [string] $Path

    [DscProperty(Mandatory)]
    [string]$Url

    [DscProperty()]
    [boolean]$Exists

    [FileDownload]Get() {
        $fileExists = Test-Path $this.Path

        if ($fileExists) {
            $this.Exists = $true
        }
        else {
            $this.Exists = $false
        }

        return $this
    }

    [boolean]Test() {
        
        if (Test-Path -Path $this.Path) {
            return $true
        }
        else {
            return $false
        }
    }

    [void]Set() {
        New-Item -Path $this.Path -ItemType Directory -Force
        Invoke-WebRequest -Uri $this.Url -OutFile $this.Path -UseBasicParsing
    }
}