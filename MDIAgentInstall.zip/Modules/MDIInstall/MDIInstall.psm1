enum Ensure {
    Present
    Absent
}

[DscResource()]
class MDIInstall {
    [DscProperty(Key)]
    [string] $Path

    [DscProperty(Mandatory)]
    [string] $AccessKey

    [DscProperty()]
    [Ensure]$Ensure

    [MDIInstall]Get() {
        return $this
    }

    [boolean]Test() {
        
        If (Get-CimInstance -Query "SELECT * FROM Win32_Product Where Name Like '%Azure Advanced Threat Protection Sensor%'") {
            return $true
        }
        else {
            return $false
        }
    }

    [void]Set() {
        #Validate supported operating system for a DC:
        if ($this.Ensure -eq "Present") {
            If (((Get-CimInstance Win32_OperatingSystem).Caption -like '*Server 2022*') -or ((Get-CimInstance Win32_OperatingSystem).Caption -like '*Server 2019*') -or ((Get-CimInstance Win32_OperatingSystem).Caption -like '*Server 2016*') -or ((Get-CimInstance Win32_OperatingSystem).Caption -like '*Server 2012 R2*')) {


                #If the server is a Domain Controller, deploy the MDI Sensor
                if ((Get-CimInstance Win32_OperatingSystem).ProductType -eq '2') {
       
                    #Check if not already installed
                    If (-Not (Get-CimInstance -Query "SELECT * FROM Win32_Product Where Name Like '%Azure Advanced Threat Protection Sensor%'")) {

                        #Expand-Archive -LiteralPath 'C:\TacMon\Defender\Azure ATP Sensor Setup.zip' -DestinationPath C:\TacMon\Defender -Force
           
                        # $MDIArgs = "/quiet NetFrameworkCommandLineArguments=""/q"" AccessKey=""$MDIAccessKEY"""

                        Start-Process -FilePath "$($this.Path)\Azure ATP sensor Setup.exe" -ArgumentList "/quiet NetFrameworkCommandLineArguments=""/q"" AccessKey=""$($this.AccessKey)"""                    

                        #If you need to specify proxy information, add in these arguments as-needed in this example (Note some proxies do not need Authentication):                
                        #
                        # Start-Process -FilePath "Azure ATP sensor Setup.exe" -ArgumentList "/quiet NetFrameworkCommandLineArguments=""/q"" AccessKey=""$MDIAccessKEY"" ProxyUrl=""http://proxy.contoso.com:8080"" ProxyUserName=""Contoso\ProxyUser"" ProxyUserPassword=""something"""                #                        
                    }


                }

            }

            #Validate supported operating system for ADFS:
            If (((Get-CimInstance Win32_OperatingSystem).Caption -like '*Server 2022*') -or ((Get-CimInstance Win32_OperatingSystem).Caption -like '*Server 2019*') -or ((Get-CimInstance Win32_OperatingSystem).Caption -like '*Server 2016*')) {


                #If the server is an ADFS Server, deploy the MDI Sensor
                If ((Get-CimInstance Win32_Service).Name -like 'adfssrv') {

                    #Check if not already installed
                    If (-Not (Get-CimInstance -Query "SELECT * FROM Win32_Product Where Name Like '%Azure Advanced Threat Protection Sensor%'")) {

                        #Expand-Archive -LiteralPath 'C:\TacMon\Defender\Azure ATP Sensor Setup.zip' -DestinationPath C:\TacMon\Defender -Force

                        Start-Process -FilePath "$($this.Path)Azure ATP sensor Setup.exe" -ArgumentList "/quiet NetFrameworkCommandLineArguments=""/q"" AccessKey=""$($this.AccessKey)"""                    
       
                    }

                }

            }
        }
    }
}